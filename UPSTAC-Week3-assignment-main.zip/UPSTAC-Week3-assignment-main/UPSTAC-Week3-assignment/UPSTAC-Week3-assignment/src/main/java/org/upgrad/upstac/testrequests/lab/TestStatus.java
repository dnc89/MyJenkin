package org.upgrad.upstac.testrequests.lab;

public enum TestStatus {
    NEGATIVE,POSITIVE
}
